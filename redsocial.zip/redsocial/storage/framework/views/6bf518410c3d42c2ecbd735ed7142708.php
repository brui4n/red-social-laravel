<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h2 class="card-title"><?php echo e($post->titulo); ?></h2>
            <p class="card-text"><?php echo e($post->contenido); ?></p>

            <?php if($post->imagen): ?>
                <img src="<?php echo e(asset('storage/' . $post->imagen)); ?>" alt="Imagen del post" class="img-fluid rounded mb-3" style="max-width: 100%;">
            <?php endif; ?>

            <?php if($post->archivo): ?>
                <p>
                    <a href="<?php echo e(asset('storage/' . $post->archivo)); ?>" target="_blank" class="btn btn-outline-secondary btn-sm">
                        📎 Descargar archivo
                    </a>
                </p>
            <?php endif; ?>

            <?php if($post->codigo): ?>
                <pre class="bg-light p-3 rounded"><code><?php echo e($post->codigo); ?></code></pre>
            <?php endif; ?>

            <?php if($post->lenguaje): ?>
                <p><strong>Lenguaje:</strong> <?php echo e($post->lenguaje); ?></p>
            <?php endif; ?>

            
            <div class="d-flex flex-wrap gap-2 mt-4">
                <form action="<?php echo e(route('posts.like', $post->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-primary btn-sm">
                        👍 <?php echo e($post->likes->count()); ?> Me gusta
                    </button>
                </form>

                <button class="btn btn-outline-success btn-sm" onclick="copiarEnlace()">📤 Compartir</button>
            </div>

            <script>
                function copiarEnlace() {
                    navigator.clipboard.writeText("<?php echo e(route('posts.show', $post->id)); ?>");
                    alert("¡Enlace copiado al portapapeles!");
                }
            </script>
        </div>
    </div>

    
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <h4 class="card-title">🗨️ Comentarios</h4>

            <?php if($post->comentarios->count()): ?>
                <?php $__currentLoopData = $post->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex align-items-start mb-3">
                        <div class="me-2">
                            <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($comentario->usuario->nombre)); ?>&background=random&color=fff"
                                 alt="Avatar" class="rounded-circle" width="40" height="40">
                        </div>
                        <div>
                            <strong><?php echo e($comentario->usuario->nombre); ?></strong><br>
                            <span><?php echo e($comentario->contenido); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p class="text-muted">Aún no hay comentarios.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <?php if(auth()->guard()->check()): ?>
    <div class="card shadow-sm" id="comentar">
        <div class="card-body">
            <form action="<?php echo e(route('comentarios.store', $post->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <textarea name="contenido" class="form-control" rows="2" placeholder="Escribe un comentario..." required></textarea>
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-primary btn-sm">💬 Comentar</button>
                </div>
            </form>
        </div>
    </div>
    <?php else: ?>
        <p class="text-muted">Debes iniciar sesión para comentar.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/voyadei/Documents/red-social-laravel/redsocial/resources/views/posts/show.blade.php ENDPATH**/ ?>