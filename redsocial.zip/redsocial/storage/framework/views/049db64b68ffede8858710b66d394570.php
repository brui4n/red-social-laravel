<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Crear nuevo post</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>¡Oops!</strong> Hay algunos problemas con tu entrada.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="titulo" class="form-label">Título</label>
            <input type="text" name="titulo" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="contenido" class="form-label">Contenido</label>
            <textarea name="contenido" class="form-control" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="imagen" class="form-label">Imagen (opcional)</label>
            <input type="file" name="imagen" class="form-control">
        </div>

        <div class="mb-3">
            <label for="archivo" class="form-label">Archivo adjunto (opcional)</label>
            <input type="file" name="archivo" class="form-control">
        </div>

        <div class="mb-3">
            <label for="codigo" class="form-label">Código (opcional)</label>
            <textarea name="codigo" class="form-control" rows="5"></textarea>
        </div>

        <div class="mb-3">
            <label for="lenguaje" class="form-label">Lenguaje del código (opcional)</label>
            <select name="lenguaje" class="form-select">
                <option value="">Selecciona un lenguaje</option>
                <option value="php">PHP</option>
                <option value="javascript">JavaScript</option>
                <option value="html">HTML</option>
                <option value="css">CSS</option>
                <option value="python">Python</option>
                <option value="java">Java</option>
                <!-- Agrega más si gustas -->
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Publicar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/voyadei/Documents/red-social-laravel/redsocial/resources/views/posts/create.blade.php ENDPATH**/ ?>