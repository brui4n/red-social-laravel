<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->check()): ?>
    <div class="container mt-5 text-center">
        <h1 class="display-4">¡Bienvenido, <?php echo e(Auth::user()->nombre); ?>!</h1>
        <p class="lead">Ya estás logueado correctamente en CodeNet.</p>

        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary mb-4">Crear nuevo post</a>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger mt-3">Cerrar sesión</button>
        </form>
    </div>

    <div class="container mt-4">
        <h2>Posts recientes</h2>
        <?php if($posts->count()): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <h4><?php echo e($post->titulo); ?></h4>
                        <p class="text-muted">Publicado por: <?php echo e($post->usuario->nombre ?? 'Usuario desconocido'); ?></p>
                        <p><?php echo e(Str::limit($post->contenido, 100)); ?></p>

                        <?php if($post->imagen): ?>
                            <img src="<?php echo e(asset('storage/' . $post->imagen)); ?>" alt="Imagen del post" style="max-width: 150px;">
                        <?php endif; ?>

                        <div class="mt-2">
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-sm btn-outline-secondary">Ver más</a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-muted">No hay posts todavía.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/voyadei/Documents/red-social-laravel/redsocial/resources/views/inicio.blade.php ENDPATH**/ ?>